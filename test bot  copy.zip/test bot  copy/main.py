from aiogram import Bot, Dispatcher, executor, types

bot = Bot('6474358746:AAFGbYtr1U6gPFDzrRn5qwhI3SSJcTPuQko')
dp = Dispatcher(bot)

@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    #await bot.senf_message(message.chat.id, 'Hello')
    await message.answer('Hello')

executor.start_polling(dp)